package com.nextclick.grocery.modal;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

import java.io.Serializable;

@Entity(tableName = "tbl_ProductCategories")
public class Productdetails implements Serializable {

    @PrimaryKey(autoGenerate = true)
    private int id;

    @ColumnInfo(name = "Category")
    private String Category;

    @ColumnInfo(name = "Name")
    private String Name;

    @ColumnInfo(name = "Discription")
    private String Discription;

    public Productdetails(String Category, String Name, String Discription) {
        this.id = id;
        this.Category = Category;
        this.Name = Name;
        this.Discription = Discription;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCategory() {
        return Category;
    }

    public void setCategory(String category) {
        Category = category;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getDiscription() {
        return Discription;
    }

    public void setDiscription(String discription) {
        Discription = discription;
    }

    public static Productdetails[] ProductsData() {
        return new Productdetails[]{
                new Productdetails("Groceries", "Daal", "Dal is a term used in the Indian subcontinent for dried, split pulses that do not require soaking before cooking. India is the largest producer of pulses in the world."),
                new Productdetails("Groceries", "Soaps", "Soap is a salt of a fatty acid used in a variety of cleansing and lubricating products"),
                new Productdetails("Groceries", "Sunflower OIL", "Sunflower oils that are not high oleic contain more omega-6, which may harm your health"),
                new Productdetails("Fruits", "Apples", "An apple is an edible fruit produced by an apple tree."),
                new Productdetails("Fruits", "Grapes", "A grape is a fruit, botanically a berry, of the deciduous woody vines of the flowering plant genus Vitis"),
                new Productdetails("Clothes", "Jeans", "Shop from the latest range of comfortable & trendy regular jeans"),
        };
    }

}
