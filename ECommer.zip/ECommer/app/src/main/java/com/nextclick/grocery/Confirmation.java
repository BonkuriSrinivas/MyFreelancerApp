package com.nextclick.grocery;

import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.nextclick.grocery.adapters.JayBaseAdapter;
import com.nextclick.grocery.modal.BeanShipping;
import com.tutorialsee.grocery.R;

import java.util.ArrayList;

public class Confirmation extends Fragment {

    private  View view;
    MyTextView pay;
    private ListView listview;
    Typeface fonts1,fonts2;
    private int[] IMAGE = {R.drawable.daal, R.drawable.soaps, R.drawable.oil,R.drawable.apple, R.drawable.grapes};
    private String[] TITLE = {"Daal", "Soaps", "Sunflower OIL", "Apples", "Grapes"};
    private String[] DESCRIPTION = {"Split pulse..", "cleansing and lubricating..", "harm your health..", "edible fruit..", "deliious fruit.."};
    private String[] DATE = {"₹ 120.00","₹ 49.00","₹ 320.00","₹ 130.00","₹ 49.00"};
    private ArrayList<BeanShipping>Bean;
    private JayBaseAdapter baseAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.confirmation, container, false);

        pay = view.findViewById(R.id.pay);
        listview = (ListView)view.findViewById(R.id.listview);
        Bean = new ArrayList<BeanShipping>();
        for (int i= 0; i< TITLE.length; i++){

            BeanShipping bean = new BeanShipping(IMAGE[i], TITLE[i], DESCRIPTION[i], DATE[i]);
            Bean.add(bean);
        }

        baseAdapter = new JayBaseAdapter(getActivity(), Bean) {
        };

        listview.setAdapter(baseAdapter);

        pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShippigPayment.viewPager.arrowScroll(View.FOCUS_RIGHT);
            }
        });

        return  view;

    }
}