package com.nextclick.grocery;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.tutorialsee.grocery.R;

public class Payment extends Fragment {
    TextView order;
    MyEditText cardno2,date2,cvv2,name2;
    String str_cardno2,str_date2,str_cvv2,str_name2;
    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.payment, container, false);

        cardno2 = view.findViewById(R.id.cardno2);
        date2 = view.findViewById(R.id.date2);
        cvv2 = view.findViewById(R.id.cvv2);
        name2 = view.findViewById(R.id.name2);
        order = view.findViewById(R.id.order);
        order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                str_cardno2 = cardno2.getText().toString();
                str_date2 = date2.getText().toString();
                str_cvv2 = cvv2.getText().toString();
                str_name2 = name2.getText().toString();

                if (str_cardno2.length() == 0) {
                    cardno2.setError("Please enter card number");
                } else if (str_date2.length() == 0) {
                    date2.setError("Please enter expiry date");
                } else if (str_cvv2.length() == 0) {
                    cvv2.setError("Please enter cvv number");
                } else if (str_name2.length() == 0) {
                    name2.setError("Please enter cardholder name");
                } else {

                }
            }
        });

        return view;
    }
}