package com.nextclick.grocery;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.tutorialsee.grocery.R;

public class AddToCart extends AppCompatActivity {
    ImageView addtocart;
    MyTextView est,itemname;
    LinearLayout lay_price;
    String str_name,str_disc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.addtocart);
        addtocart = (ImageView) findViewById(R.id.addtocart);
        est = findViewById(R.id.est);
        itemname = findViewById(R.id.itemname);
        lay_price = findViewById(R.id.lay_price);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            str_name = extras.getString("name");
            str_disc = extras.getString("discrip");
        }

        est.setText(str_name);
        itemname.setText(str_disc);

        addtocart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ii = new Intent(getApplicationContext(), ShippigPayment.class);
                startActivity(ii);
            }
        });

        lay_price.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ii = new Intent(getApplicationContext(), ShippigPayment.class);
                startActivity(ii);
            }
        });
    }
}
